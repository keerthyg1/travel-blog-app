# Usage
install nodejs
and after this watch 
https://youtu.be/UfeqbB3SLfI 
=====================
# In new terminal --> 

 npm start
 Or
 npm run dev 
# Visit http://localhost:3000
